var config = {
    paths: {
        'flatpickr': 'FireAds_Referencer/js/flatpickr.min',
        'orders': 'FireAds_Referencer/js/orders',
        'activity': 'FireAds_Referencer/js/activity'
    }
};
